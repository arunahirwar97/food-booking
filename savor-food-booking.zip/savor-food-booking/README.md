# 🍽 SAVOR — Premium Food Booking Website

A beautiful, fully interactive food booking website with table reservations, online ordering, cart management, and more.

## ✨ Features

- **Hero Section** — Animated landing with floating food plate
- **Menu Browser** — 20+ dishes with category filters & live search
- **Table Booking** — Full reservation form with validation and confirmation
- **Online Ordering** — Add to cart, quantity control, delivery form, order tracking
- **Cart System** — Real-time cart with floating button
- **Testimonials** — Guest reviews section
- **Contact Form** — Message form with validation
- **Fully Responsive** — Works on mobile, tablet, desktop

---

## 🚀 Deploy on Render (Step-by-Step)

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: SAVOR food booking site"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/savor-food-booking.git
git push -u origin main
```

### Step 2 — Create Render Account
Go to [https://render.com](https://render.com) and sign up (free).

### Step 3 — New Web Service
1. Click **"New +"** → **"Web Service"**
2. Connect your GitHub account
3. Select the `savor-food-booking` repository

### Step 4 — Configure Settings
| Setting | Value |
|---|---|
| **Name** | savor-food-booking |
| **Environment** | Node |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Instance Type** | Free |

### Step 5 — Deploy!
Click **"Create Web Service"** — Render will build and deploy automatically.

Your site will be live at: `https://savor-food-booking.onrender.com`

---

## 💻 Run Locally

```bash
npm install
npm start
# Open http://localhost:3000
```

---

## 📁 Project Structure

```
savor-food-booking/
├── public/
│   ├── index.html     # Main HTML
│   ├── style.css      # All styles
│   └── app.js         # All JavaScript
├── server.js          # Express server
├── package.json
├── render.yaml        # Render config
└── README.md
```
